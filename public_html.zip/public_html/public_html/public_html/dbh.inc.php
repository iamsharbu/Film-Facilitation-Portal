<?php
$dbServername="localhost";
$dbUsername="id5938349_iamsharbu";
$dbPassword="sharbu618139";
$dbName="id5938349_delhifilmportal";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

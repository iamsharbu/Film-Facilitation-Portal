<?php
include 'dbh.inc.php';

$userid=mysqli_real_escape_string($conn,$_POST['usrid']);
$dataquery="SELECT * FROM dataforms WHERE userid='$userid'";
mysqli_select_db($conn,'id5938349_delhifilmportal');
$resultrow=mysqli_query($conn,$dataquery);
if (mysqli_num_rows($resultrow)<1)
{
  header('Refresh:2; url=policedepartment.php');
  echo '<script type="text/javascript">
  window.alert("Not a valid user id!")
  </script>';
}
else{
$check="SELECT policedepartment FROM dataforms WHERE userid='$userid'";
mysqli_select_db($conn,'id5938349_delhifilmportal');

$result=mysqli_query($conn,$check);
$row=mysqli_fetch_assoc($result);
if($row['policedepartment']=='approved')
{
  header('Refresh:2; url=policedepartment.php');
  echo '<script type="text/javascript">
  window.alert("Already approved!")
  </script>';
}
else {


  $query="UPDATE dataforms SET policedepartment='approved' WHERE userid='$userid'";
  if(!mysqli_query($conn,$query))
  {
    header('Refresh:2; url=policedepartment.php');
    echo '<script type="text/javascript">
    window.alert("not approved!")
    </script>';
  }
  else {
    header('Refresh:2; url=policedepartment.php');
    echo '<script type="text/javascript">
    window.alert("Successfully approved!")
    </script>';
  }

}
}
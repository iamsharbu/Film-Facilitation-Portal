<?php
$dbServername="localhost";
$dbUsername="id2646967_iamsharbu";
$dbPassword="sharbu123";
$dbName="loginsystem";

$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
